export enum PresetDate {
  ALL_TIME = "All time",
  THIS_MONTH = "Bulan ini",
  LAST_MONTH = "Bulan lalu",
  THIS_YEAR = "Tahun ini",
  CUSTOM = "Pilih tanggal tertentu",
}
