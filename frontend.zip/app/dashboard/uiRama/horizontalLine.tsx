import React from "react";

const HorizontalLine: React.FC = () => {
  return <div className="border-t border-gray-300 my-4"></div>;
};

export default HorizontalLine;
