import React from "react";
import FormMateri from "./components/FormMateri";

export default function FormMateriPage() {
  return <FormMateri />;
}
